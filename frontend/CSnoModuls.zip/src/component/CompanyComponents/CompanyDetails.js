import { useRef } from "react";
import { useState } from 'react';
import { useHistory } from "react-router-dom";

const CompanyDetails = () => {

    const nameRef = useRef(null)
    const emailRef = useRef(null)
    const passwordRef = useRef(null)
    const history = useHistory()
    const [error, setError] = useState(null)

    const handleUpdateSubmituon = async (event) => {
        event.preventDefault()

        const name = nameRef.current.value
        const email = emailRef.current.value
        const password = passwordRef.current.value

        await fetch('http://localhost:8080/api/companies/update-company?token=' + localStorage.getItem('token'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, email, password })
        })
        // if (!response.ok) {
        //   if (response.status === 403) {
        //throw new Error('30 minutes passed since your last action please login again')
        // }
        // } 
      console.log("Your details changed successfully")
    }
        return (
            <form onSubmit={handleUpdateSubmituon}>
                <h2>Name:</h2>
                <input type="name" ref={nameRef} />
                <h2>Email:</h2>
                <input type="email" ref={emailRef} />
                <h2>Password:</h2>
                <input type="password" ref={passwordRef} />
                <br />
                <button type="submit">update</button>
            </form>
        )
    }


export default CompanyDetails
