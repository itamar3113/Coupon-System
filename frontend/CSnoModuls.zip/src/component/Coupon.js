
const Coupon = (props) => {

    const parchaseCoupon = async () => {
        try {
            const response = await fetch('http://localhost:8080/api//customers/purchase/' +
                props.id + '?token=' + localStorage.getItem('token'), {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
            })
            if (!response.ok) {
                throw new Error(response.stringify)
            }
            const data = await response.json()
            console.log(data)
        } catch (error) {
            console.log(error);
        }
    }

    const deleteCoupon = () => {
        if (window.confirm('Are you sure you want to delete this coupon?')) {
            try {
                fetch('http://localhost:8080/api//companies/delete-coupon/' +
                    props.id + '?token=' + localStorage.getItem('token'), {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                })
                console.log('Coupon ' + props.id + ' deleted')
            } catch (error) {
                console.log(error)
            }
        }
    }

    let purchaseOrDelete = null
    if (localStorage.getItem('clientType') === '/customer') {
        purchaseOrDelete = <button onClick={parchaseCoupon}>Parchase</button>
    } else {
        purchaseOrDelete = <button onClick={deleteCoupon}>Delete</button>
    }


    return (
        <li>
            <h4>{props.id}</h4>
            <h2>{props.title}</h2>
            <img src={props.imageUrl} width="200" alt={props.name} />
            <h3>Price: {props.price}</h3>
            <h4>End date: {props.endDate}</h4>
            <p>{props.description}</p>
            {purchaseOrDelete}
        </li>
    )
}

export default Coupon