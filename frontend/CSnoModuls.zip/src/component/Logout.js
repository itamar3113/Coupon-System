import { useDispatch } from "react-redux"
import { useHistory } from "react-router-dom";
import { authActions } from "../store/authSlice";

const Logout = () => {

    const dispatch = useDispatch()
    const history = useHistory()

    const logoutHandler = () =>{
        dispatch(authActions.logout())
        history.replace('login')
    }
    return (
        <button onClick={logoutHandler}>Logout</button>
    )
}

export default Logout