import { useRef } from "react";
import { useState } from 'react';
import { useHistory } from "react-router";

const PersonalDetails = () => {

    const firstNameRef = useRef(null)
    const lastNameRef = useRef(null)
    const emailRef = useRef(null)
    const passwordRef = useRef(null)
    const history = useHistory()

    const handleUpdateSubmituon = async (event) => {
        event.preventDefault()

        const firstName = firstNameRef.current.value
        const lastName = lastNameRef.current.value
        const email = emailRef.current.value
        const password = passwordRef.current.value

        try {
            const response = await fetch('http://localhost:8080/api/customers/update-customer?token=' + localStorage.getItem('token'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ firstName, lastName, email, password })
            })
            if (response.status === 403) {
                throw new Error('30 minutes passed since your last action please login again')
            }
            console.log("Your personal detail changed successfully")
        } catch (error) {
            window.alert(error.message)
            history.replace('/login')
        }
    }

    /*
    const [details, setDetails] = useState({})
 
    const cuurentDetails = async () => {
          try {
              const response = await fetch('http://localhost:8080/api//customers?token=' + localStorage.getItem('token'), {
                  method: 'GET',
                  headers: {
                      'Content-Type': 'application/json'
                  },
              })
              if (!response.ok) {
                  throw new Error(response.stringify)
              }
              const data = await response.json()
              setDetails(data)
          } catch (error) {
              console.log(error);
          }
      } */

    return (
        <form onSubmit={handleUpdateSubmituon}>
            <h2>First Name:</h2>
            <input type="firstName" ref={firstNameRef} />
            <h2>Last Name:</h2>
            <input type="lasttName" ref={lastNameRef} />
            <h2>Email:</h2>
            <input type="email" ref={emailRef} />
            <h2>Password:</h2>
            <input type="password" ref={passwordRef} />
            <br />
            <button type="submit">update</button>
        </form>
    )
}

export default PersonalDetails
