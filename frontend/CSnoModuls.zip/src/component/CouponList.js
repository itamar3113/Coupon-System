import Coupon from "./Coupon";

const CouponList = (props) => {
    return (
        <ul>
            {props.coupons.map(coupon => <Coupon
                id={coupon.id}
                title={coupon.title}
                imageUrl={coupon.imageUrl}
                price={coupon.price}
                endDate={coupon.endDate}
                description={coupon.description} />
            )}
        </ul>
    )
}

export default CouponList