const Home = () => {
    const handleLogout = () => {
        /* handle */
    
    }

    return (
        <>
        <h1>Home page</h1>
        <button onClick={handleLogout}>Logout</button>
    </>
    )
}

export default Home;